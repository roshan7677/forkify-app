export const API_URL = `https://forkify-api.jonas.io/api/v2/recipes`;
export const TIMEOUT_SEC = 120;
export const RES_PER_PAGE = 10;
export const API_KEY = 'a4e4ba76-2741-4f34-bc30-25b165e8fa4a';
export const MODAL_CLOSE_SEC = 2.5;
